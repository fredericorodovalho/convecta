import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { summaryRow } from "@/lib/summary-row";

export type SummaryRow = {
  id: string;
  user_id: string;
  unit: string;
  convention: string;
  validity: string | null;
  content: string;
  document_path: string | null;
  document_name: string | null;
  created_at: string;
  updated_at: string;
};

const saveSchema = z.object({
  id: z.string().uuid().optional(),
  unit: z.string().trim().min(1).max(200),
  convention: z.string().trim().min(1).max(500),
  validity: z.string().trim().max(200).optional().or(z.literal("")),
  content: z.string().min(1).max(500000),
  documentPath: z.string().max(600).optional().or(z.literal("")),
  documentName: z.string().max(300).optional().or(z.literal("")),
});

export const listSummaries = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("cct_summaries")
      .select("*")
      .order("updated_at", { ascending: false });
    if (error) throw new Error("Não foi possível carregar a biblioteca de resumos.");
    return (data ?? []) as SummaryRow[];
  });

export const saveSummary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => saveSchema.parse(data))
  .handler(async ({ context, data }) => {
    // Storage objects live only inside the owner's private folder.
    if (data.documentPath && !data.documentPath.startsWith(`${context.userId}/`))
      throw new Error("Documento fora da sua pasta privada.");
    const row = summaryRow(data, context.userId);
    if (data.id) {
      const { error } = await context.supabase.from("cct_summaries").update(row).eq("id", data.id);
      if (error) throw new Error("Não foi possível atualizar o resumo.");
      return data.id;
    }
    const { data: created, error } = await context.supabase
      .from("cct_summaries")
      .insert(row)
      .select("id")
      .single();
    if (error || !created) throw new Error("Não foi possível salvar o resumo.");
    return created.id as string;
  });

export const deleteSummary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => z.string().uuid().parse(data))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase.from("cct_summaries").delete().eq("id", data);
    if (error) throw new Error("Não foi possível excluir o resumo.");
    return true;
  });
