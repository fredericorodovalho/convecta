export async function readDocument(file: File): Promise<string> {
  if (file.size > 10 * 1024 * 1024) throw new Error("O arquivo deve ter até 10 MB.");
  const ext = file.name.split(".").pop()?.toLowerCase();
  let text = "";
  if (ext === "txt" || ext === "md") text = await file.text();
  else if (ext === "docx") {
    const mammoth = await import("mammoth/mammoth.browser");
    text = (await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() })).value;
  } else if (ext === "pdf") {
    const pdfjs = await import("pdfjs-dist");
    const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
    pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
    const task = pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) });
    const pdf = await task.promise;
    const pages: string[] = [];
    try {
      for (let n = 1; n <= pdf.numPages; n++) {
        const page = await pdf.getPage(n);
        const content = await page.getTextContent();
        const pageText = content.items
          .map((item) => ("str" in item ? item.str : ""))
          .join(" ")
          .trim();
        if (pageText) pages.push(`Página ${n}\n${pageText}`);
      }
      text = pages.join("\n\n");
    } finally {
      await task.destroy();
    }
  } else throw new Error("Envie um PDF, DOCX, TXT ou MD.");
  if (!text.trim())
    throw new Error(
      "Não encontrei texto no arquivo. Se for digitalizado, cole o texto da convenção.",
    );
  if (text.length > 500000) throw new Error("Documento muito extenso. Divida em arquivos menores.");
  return text;
}
