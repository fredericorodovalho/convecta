export type SummaryInput = {
  unit: string;
  convention: string;
  validity?: string | undefined;
  content: string;
  documentPath?: string | undefined;
  documentName?: string | undefined;
};

/**
 * Builds the library row for a saved summary.
 *
 * The owner policy on the table only accepts a document when its path lives
 * inside the owner's own private folder, so an absent document has to be stored
 * as NULL — an empty string is rejected by the policy and the save fails.
 */
export function summaryRow(input: SummaryInput, userId: string) {
  const path = input.documentPath?.trim() ?? "";
  const name = input.documentName?.trim() ?? "";
  return {
    user_id: userId,
    unit: input.unit.trim(),
    convention: input.convention.trim(),
    validity: input.validity?.trim() || "",
    content: input.content,
    document_path: path || null,
    document_name: name || null,
    updated_at: new Date().toISOString(),
  };
}
