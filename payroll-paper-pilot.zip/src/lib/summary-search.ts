export type SearchableSummary = {
  unit: string;
  convention: string;
  validity: string | null;
  content: string;
};

export function normalizeSearch(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

export function filterSummaries<T extends SearchableSummary>(
  rows: T[],
  filters: { query: string; unit: string; validity: string },
) {
  const terms = normalizeSearch(filters.query).split(/\s+/).filter(Boolean);
  return rows.filter((row) => {
    if (filters.unit && row.unit !== filters.unit) return false;
    if (filters.validity && row.validity !== filters.validity) return false;
    const text = normalizeSearch([row.unit, row.convention, row.validity ?? "", row.content].join(" "));
    return terms.every((term) => text.includes(term));
  });
}

/** Returns the paragraphs/clauses of the content that mention any search term. */
export function matchingClauses(content: string, query: string, limit = 5) {
  const terms = normalizeSearch(query).split(/\s+/).filter((t) => t.length > 1);
  if (!terms.length) return [];
  const blocks = content.split(/\n\s*\n|\n(?=\s*(?:[-*#|]|\d+[.)]|cl[aá]usula))/i).map((b) => b.trim()).filter(Boolean);
  return blocks.filter((b) => terms.some((t) => normalizeSearch(b).includes(t))).slice(0, limit);
}