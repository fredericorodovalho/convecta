import { queryOptions } from "@tanstack/react-query";
import { listSummaries } from "@/lib/summaries.server";

export const summariesQuery = queryOptions({
  queryKey: ["cct-summaries"],
  queryFn: () => listSummaries(),
});