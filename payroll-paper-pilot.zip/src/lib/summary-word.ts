import {
  BorderStyle,
  Document,
  Packer,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableRow,
  TextRun,
  VerticalAlign,
  WidthType,
} from "docx";

export type WordSummary = {
  unit: string;
  convention: string;
  validity?: string | null;
  content: string;
  updated_at?: string;
};

const BORDER = { style: BorderStyle.SINGLE, size: 1, color: "B9C2D2" };
const CELL_BORDERS = { top: BORDER, bottom: BORDER, left: BORDER, right: BORDER };
const HEADER_FILL = "DCE6F1";
const MUTED = "5A6478";
// A4 with 1-inch margins: 11906 - 1440*2 = 9026 DXA of content width.
const CONTENT_WIDTH = 9026;
const UNIT_WIDTH = 2300;
const CONVENTION_WIDTH = CONTENT_WIDTH - UNIT_WIDTH;
const MARGINS = { top: 100, bottom: 100, left: 120, right: 120 };
const FONT = "Arial";

function inlineRuns(text: string, baseBold = false, size = 20): TextRun[] {
  const runs: TextRun[] = [];
  for (const part of text.split(/(\*\*[^*]+\*\*)/g)) {
    if (!part) continue;
    const isBold = part.length > 4 && part.startsWith("**") && part.endsWith("**");
    runs.push(
      new TextRun({
        text: isBold ? part.slice(2, -2) : part,
        bold: baseBold || isBold,
        size,
        font: FONT,
      }),
    );
  }
  return runs.length ? runs : [new TextRun({ text: "", size, font: FONT })];
}

/** Minimal markdown to Word paragraphs: headings, bullets and numbered items. */
export function markdownToParagraphs(markdown: string): Paragraph[] {
  const paragraphs: Paragraph[] = [];
  for (const raw of markdown.replace(/\r\n?/g, "\n").split("\n")) {
    const line = raw.trimEnd();
    if (!line.trim()) continue;
    const heading = line.match(/^(#{1,4})\s+(.*)$/);
    if (heading) {
      paragraphs.push(
        new Paragraph({
          spacing: { before: 180, after: 80 },
          children: inlineRuns((heading[2] ?? "").replace(/\*\*/g, ""), true, (heading[1] ?? "").length <= 2 ? 22 : 20),
        }),
      );
      continue;
    }
    const bullet = line.match(/^\s*[-*•]\s+(.*)$/);
    if (bullet) {
      paragraphs.push(
        new Paragraph({
          bullet: { level: 0 },
          spacing: { after: 60 },
          children: inlineRuns(bullet[1] ?? ""),
        }),
      );
      continue;
    }
    const numbered = line.match(/^\s*(\d+)[.)]\s+(.*)$/);
    if (numbered) {
      paragraphs.push(
        new Paragraph({
          indent: { left: 420, hanging: 280 },
          spacing: { after: 60 },
          children: [
            new TextRun({ text: `${numbered[1] ?? ""}. `, bold: true, size: 20 }),
            ...inlineRuns(numbered[2] ?? ""),
          ],
        }),
      );
      continue;
    }
    paragraphs.push(new Paragraph({ spacing: { after: 120 }, children: inlineRuns(line) }));
  }
  return paragraphs;
}

function summaryBlocks(summary: WordSummary): (Table | Paragraph)[] {
  const header = new TableRow({
    tableHeader: true,
    children: [
      new TableCell({
        borders: CELL_BORDERS,
        width: { size: UNIT_WIDTH, type: WidthType.DXA },
        shading: { fill: HEADER_FILL, type: ShadingType.CLEAR },
        margins: MARGINS,
        verticalAlign: VerticalAlign.CENTER,
        children: [
          new Paragraph({
            children: [new TextRun({ text: "UNIDADE", bold: true, size: 20, font: FONT })],
          }),
        ],
      }),
      new TableCell({
        borders: CELL_BORDERS,
        width: { size: CONVENTION_WIDTH, type: WidthType.DXA },
        shading: { fill: HEADER_FILL, type: ShadingType.CLEAR },
        margins: MARGINS,
        verticalAlign: VerticalAlign.CENTER,
        children: [
          new Paragraph({
            children: [new TextRun({ text: "CONVENÇÃO", bold: true, size: 20, font: FONT })],
          }),
        ],
      }),
    ],
  });

  const content = new TableRow({
    children: [
      new TableCell({
        borders: CELL_BORDERS,
        width: { size: UNIT_WIDTH, type: WidthType.DXA },
        margins: MARGINS,
        children: [
          new Paragraph({
            spacing: { after: 60 },
            children: [new TextRun({ text: summary.unit, bold: true, font: FONT })],
          }),
          ...(summary.validity
            ? [
                new Paragraph({
                  spacing: { after: 60 },
                  children: [
                    new TextRun({ text: `Vigência: ${summary.validity}`, size: 18, color: MUTED, font: FONT }),
                  ],
                }),
              ]
            : []),
        ],
      }),
      new TableCell({
        borders: CELL_BORDERS,
        width: { size: CONVENTION_WIDTH, type: WidthType.DXA },
        margins: MARGINS,
        children: [
          new Paragraph({
            spacing: { after: 140 },
            children: [new TextRun({ text: summary.convention, bold: true, font: FONT })],
          }),
          ...(markdownToParagraphs(summary.content).length
            ? markdownToParagraphs(summary.content)
            : [
                new Paragraph({
                  children: [new TextRun({ text: "Sem conteúdo registrado.", font: FONT })],
                }),
              ]),
        ],
      }),
    ],
  });

  return [
    new Table({
      width: { size: CONTENT_WIDTH, type: WidthType.DXA },
      columnWidths: [UNIT_WIDTH, CONVENTION_WIDTH],
      rows: [header, content],
    }),
    new Paragraph({ spacing: { after: 260 }, children: [] }),
  ];
}

export function buildSummariesDoc(summaries: WordSummary[]): Document {
  return new Document({
    sections: [
      {
        properties: {
          page: {
            size: { width: 11906, height: 16838 },
            margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
          },
        },
        children: [
          new Paragraph({
            spacing: { after: 60 },
            children: [
              new TextRun({ text: "Análise de Convenções Coletivas", bold: true, size: 34, font: FONT }),
            ],
          }),
          new Paragraph({
            spacing: { after: 320 },
            children: [
              new TextRun({
                text: `Convecta — Inteligência trabalhista • ${new Date().toLocaleDateString("pt-BR")} • ${summaries.length} resumo${summaries.length === 1 ? "" : "s"}`,
                size: 18,
                color: MUTED,
                font: FONT,
              }),
            ],
          }),
          ...summaries.flatMap(summaryBlocks),
        ],
      },
    ],
  });
}

export async function summariesToBlob(summaries: WordSummary[]): Promise<Blob> {
  return Packer.toBlob(buildSummariesDoc(summaries));
}
