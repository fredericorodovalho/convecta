import type { FileUIPart } from "ai";

export const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
export function validateImage(file: Pick<File, "type" | "size">) {
  if (!IMAGE_TYPES.includes(file.type)) throw new Error("Envie uma imagem JPG, PNG ou WEBP.");
  if (!file.size) throw new Error("A imagem está vazia.");
  if (file.size > 10 * 1024 * 1024) throw new Error("A imagem deve ter até 10 MB.");
}

export async function readImage(file: File): Promise<FileUIPart> {
  validateImage(file);
  const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
  try {
    const scale = Math.min(1, 2400 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Não foi possível preparar a imagem.");
    // Flatten transparency onto white paper before JPEG encoding.
    context.fillStyle = "white";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    const url = canvas.toDataURL("image/jpeg", 0.9);
    if (url.length > 2800000) throw new Error("Imagem muito detalhada. Recorte a cláusula e envie novamente.");
    return { type: "file", mediaType: "image/jpeg", filename: file.name, url };
  } finally {
    bitmap.close();
  }
}