import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage, type FileUIPart } from "ai";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, Link } from "@tanstack/react-router";
import {
  ArrowUp,
  ArrowUpRight,
  BookOpen,
  BookmarkPlus,
  Check,
  ChevronRight,
  Copy,
  FileText,
  FolderOpen,
  ListChecks,
  Menu,
  MessageSquare,
  Paperclip,
  Plus,
  Scale,
  ShieldCheck,
  Square,
  Trash2,
  X,
  Download,
  PanelLeftClose,
  CircleHelp,
  Search,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageContent,
  MessageResponse,
  MessageActions,
  MessageAction,
} from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputTextarea,
  PromptInputFooter,
  PromptInputSubmit,
  type PromptInputMessage,
} from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Reasoning, ReasoningTrigger, ReasoningContent } from "@/components/ai-elements/reasoning";
import { useChatWorkspace } from "./chat-workspace";
import { readDocument } from "@/lib/document-reader";
import { readImage } from "@/lib/image-reader";
import { supabase } from "@/integrations/supabase/client";
import { saveSummary } from "@/lib/summaries.server";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import mark from "@/assets/convecta-mark.png";

const suggestions = [
  {
    icon: FileText,
    title: "Analisar uma convenção",
    text: "Obrigações, prazos e impactos para o RH",
    question: "Quero analisar integralmente uma CCT. Quais documentos você precisa?",
  },
  {
    icon: Scale,
    title: "Consultar uma cláusula",
    text: "Reajustes, benefícios e jornada de trabalho",
    question:
      "Como interpretar uma cláusula de convenção coletiva sem confundir obrigação expressa e interpretação?",
  },
  {
    icon: ListChecks,
    title: "Criar um checklist",
    text: "Providências práticas para o Departamento Pessoal",
    question:
      "Quero um checklist de cumprimento da minha CCT para o RH/DP. Quais informações preciso fornecer?",
  },
  {
    icon: BookOpen,
    title: "Comparar convenções",
    text: "O que mudou entre a CCT anterior e a atual",
    question:
      "Quero comparar a CCT atual com a anterior. Quais documentos você precisa para identificar alterações com segurança?",
  },
];
const topics = ["Reajuste salarial", "Piso salarial", "Banco de horas", "Benefícios", "Rescisão"];
function IconControl({
  label,
  children,
  onClick,
}: {
  label: string;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button variant="ghost" size="icon-sm" aria-label={label} onClick={onClick}>
          {children}
        </Button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  );
}
export function CctChat({
  threadId = "welcome",
  initialMessages = [],
  pending = false,
}: {
  threadId?: string;
  initialMessages?: UIMessage[];
  pending?: boolean;
}) {
  const { threads, add, save, remove } = useChatWorkspace();
  const navigate = useNavigate();
  const [sidebar, setSidebar] = useState(false);
  const [text, setText] = useState("");
  const [document, setDocument] = useState<{ name: string; text: string } | null>(null);
  const [images, setImages] = useState<FileUIPart[]>([]);
  const [reading, setReading] = useState(false);
  const [notice, setNotice] = useState("");
  const [copied, setCopied] = useState("");
  const [help, setHelp] = useState(false);
  const [saveFor, setSaveFor] = useState("");
  const [saveForm, setSaveForm] = useState({ unit: "", convention: "", validity: "" });
  const [saveFile, setSaveFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState("");
  const input = useRef<HTMLTextAreaElement>(null);
  const upload = useRef<HTMLInputElement>(null);
  const transport = useMemo(() => new DefaultChatTransport({ api: "/api/chat" }), []);
  const { messages, sendMessage, regenerate, status, stop, error, clearError } = useChat({
    id: threadId,
    messages: initialMessages,
    transport,
    onError: (e) => setNotice(e.message),
    onFinish: () => input.current?.focus(),
  });
  const busy = status === "submitted" || status === "streaming";
  const submittedFirst = useRef(false);
  useEffect(() => {
    if (
      !pending ||
      submittedFirst.current ||
      initialMessages.length !== 1 ||
      initialMessages[0]?.role !== "user"
    )
      return;
    // Wait for the routed component to commit; navigation cleanup must not cancel its first request.
    const timer = setTimeout(() => {
      submittedFirst.current = true;
      void regenerate().catch((e) =>
        setNotice(e instanceof Error ? e.message : "Não foi possível enviar a pergunta."),
      );
    }, 0);
    return () => clearTimeout(timer);
  }, [pending, initialMessages, regenerate]);
  useEffect(() => {
    if (threadId !== "welcome" && messages.length) save(threadId, messages);
  }, [threadId, messages, save]);
  useEffect(() => {
    if (!busy && !help) input.current?.focus();
  }, [busy, help]);
  function newThread() {
    stop();
    const id = add();
    setSidebar(false);
    void navigate({ to: "/chat/$threadId", params: { threadId: id }, search: { pending: false } });
  }
  function send(question: string) {
    if (busy || reading || (!question.trim() && !document && !images.length)) return;
    setNotice("");
    clearError();
    const fullText = document
      ? `${question.trim() || "Analise integralmente esta convenção coletiva conforme seu roteiro de RH/DP."}\n\nDocumento: ${document.name}\n<documento>\n${document.text}\n</documento>`
      : question.trim() || "Analise as cláusulas visíveis nas imagens anexadas e destaque obrigações, valores e dúvidas para o RH/DP.";
    if (threadId === "welcome") {
      const id = add();
      save(id, [
        { id: crypto.randomUUID(), role: "user", parts: [{ type: "text", text: fullText }, ...images] },
      ]);
      // The new routed chat submits its pending first message once after mounting.
      void navigate({ to: "/chat/$threadId", params: { threadId: id }, search: { pending: true } });
    } else void sendMessage({ text: fullText, files: images });
    setText("");
    setDocument(null);
    setImages([]);
    input.current?.focus();
  }
  async function attach(file?: File) {
    if (!file) return;
    setReading(true);
    setNotice("");
    try {
      if (file.type.startsWith("image/")) {
        if (images.length >= 4) throw new Error("Envie até 4 imagens por pergunta.");
        const image = await readImage(file);
        setImages((current) => [...current, image]);
        return;
      }
      const extracted = await readDocument(file);
      setDocument({ name: file.name, text: extracted });
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "Não foi possível ler o documento.");
    } finally {
      setReading(false);
      if (upload.current) upload.current.value = "";
      input.current?.focus();
    }
  }
  async function copy(id: string, value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(id);
      setTimeout(() => setCopied(""), 1800);
    } catch {
      setNotice("Não foi possível copiar a resposta.");
    }
  }
  function download() {
    if (!messages.length) return;
    const report = messages
      .map(
        (m) =>
          `${m.role === "user" ? "## Pergunta" : "## Convecta"}\n\n${m.parts
            .filter((p) => p.type === "text")
            .map((p) => (p.type === "text" ? p.text : ""))
            .join("\n")}`,
      )
      .join("\n\n---\n\n");
    const url = URL.createObjectURL(new Blob([report], { type: "text/markdown;charset=utf-8" }));
    const a = window.document.createElement("a");
    a.href = url;
    a.download = "pesquisa-convecta.md";
    a.click();
    URL.revokeObjectURL(url);
  }
  function messageText(message: UIMessage) {
    return message.parts
      .filter((p) => p.type === "text")
      .map((p) => (p.type === "text" ? p.text : ""))
      .join("\n");
  }
  async function submitSave() {
    if (!saveFor || saving) return;
    const unit = saveForm.unit.trim();
    const convention = saveForm.convention.trim();
    if (!unit || !convention) {
      setNotice("Informe a unidade e a convenção antes de salvar.");
      return;
    }
    setSaving(true);
    setNotice("");
    try {
      const { data } = await supabase.auth.getUser();
      if (!data.user) {
        // The library is private: sign in first, then return to this same research.
        try {
          sessionStorage.setItem("convecta-pos-login", window.location.href);
        } catch {
          /* storage unavailable */
        }
        setSaveFor("");
        void navigate({ to: "/auth" });
        return;
      }
      let documentPath = "";
      let documentName = "";
      if (saveFile) {
        const safeName = saveFile.name.replace(/[^\w.\-]+/g, "_").slice(0, 120);
        const path = `${data.user.id}/${Date.now()}-${safeName}`;
        const { error: uploadError } = await supabase.storage
          .from("summary-documents")
          .upload(path, saveFile);
        if (uploadError) throw new Error("Não foi possível guardar o documento original.");
        documentPath = path;
        documentName = saveFile.name;
      }
      await saveSummary({
        data: {
          unit,
          convention,
          validity: saveForm.validity.trim(),
          content: saveFor,
          documentPath,
          documentName,
        },
      });
      setSaveFor("");
      setSaveForm({ unit: "", convention: "", validity: "" });
      setSaveFile(null);
      setSaved("Resumo salvo na sua biblioteca.");
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "Não foi possível salvar o resumo.");
    } finally {
      setSaving(false);
    }
  }
  return (
    <TooltipProvider>
      <div className="workspace">
        {sidebar && <div className="sidebar-backdrop" onClick={() => setSidebar(false)} />}
        <aside className={`sidebar ${sidebar ? "sidebar-open" : ""}`}>
          <Link to="/" className="brand">
            <img src={mark} alt="" width={40} height={40} />
            <span>
              convecta<span className="brand-dot">.</span>
            </span>
          </Link>
          <div className="workspace-label">INTELIGÊNCIA TRABALHISTA</div>
          <Button onClick={newThread} className="new-research">
            <Plus size={18} /> Nova pesquisa
          </Button>
          <div className="nav-section">
            <div className="section-label">ESPAÇO DE TRABALHO</div>
            <Button
              variant="ghost"
              className="nav-item active"
              onClick={() => {
                setSidebar(false);
                input.current?.focus();
              }}
            >
              <MessageSquare size={18} /> Assistente CCT <span className="nav-count">IA</span>
            </Button>
            <Button variant="ghost" className="nav-item" asChild>
              <Link to="/pesquisa" onClick={() => setSidebar(false)}>
                <Search size={18} /> Consulta de cláusulas
              </Link>
            </Button>
            <Button variant="ghost" className="nav-item" asChild>
              <Link to="/biblioteca" onClick={() => setSidebar(false)}>
                <BookOpen size={18} /> Biblioteca de resumos
              </Link>
            </Button>
          </div>
          <div className="thread-section">
            <div className="section-label">
              NESTA SESSÃO <span>{threads.length.toString().padStart(2, "0")}</span>
            </div>
            {threads.length ? (
              <div className="thread-list">
                {threads.map((t) => (
                  <div className={`thread-row ${t.id === threadId ? "selected" : ""}`} key={t.id}>
                    <Link
                      to="/chat/$threadId"
                      params={{ threadId: t.id }}
                      search={{ pending: false }}
                      onClick={() => setSidebar(false)}
                    >
                      <MessageSquare size={14} />
                      <span>{t.title}</span>
                    </Link>
                    <IconControl
                      label="Excluir conversa"
                      onClick={() => {
                        if (t.id === threadId) {
                          stop();
                          void navigate({ to: "/" });
                        }
                        remove(t.id);
                      }}
                    >
                      <Trash2 size={13} />
                    </IconControl>
                  </div>
                ))}
              </div>
            ) : (
              <div className="session-empty">
                <FolderOpen size={24} strokeWidth={1.4} />
                <p>Nenhuma pesquisa iniciada</p>
              </div>
            )}
          </div>
          <div className="sidebar-bottom">
            <div className="session-note">
              <ShieldCheck size={17} />
              <div>
                <strong>Sessão temporária</strong>
                <span>Histórico não armazenado</span>
              </div>
            </div>
            <div className="profile">
              <div className="profile-avatar">RH</div>
              <div>
                <strong>Seu espaço de pesquisa</strong>
                <span>RH & Departamento Pessoal</span>
              </div>
              <IconControl label="Sobre o assistente" onClick={() => setHelp(true)}>
                <CircleHelp size={17} />
              </IconControl>
            </div>
          </div>
        </aside>
        <main className="main-workspace">
          <header className="workspace-header">
            <div className="header-path">
              <span className="mobile-menu">
                <IconControl label="Abrir menu" onClick={() => setSidebar(true)}>
                  <Menu />
                </IconControl>
              </span>
              <MessageSquare size={17} />
              <span>Assistente CCT</span>
              <ChevronRight size={13} />
              <span className="path-current">
                {messages.length ? "Pesquisa em andamento" : "Nova pesquisa"}
              </span>
            </div>
            <div className="header-actions">
              <span className="availability">
                <i /> Assistente disponível
              </span>
              <IconControl label="Exportar conversa" onClick={download}>
                <Download size={17} />
              </IconControl>
            </div>
          </header>
          <section className={`chat-area ${messages.length ? "has-messages" : ""}`}>
            {!messages.length ? (
              <div className="empty-experience">
                <div className="assistant-badge">
                  <span className="badge-line" /> ESPECIALISTA EM CCT & ACT
                </div>
                <h1>
                  Clareza para cada
                  <br />
                  <span>decisão trabalhista.</span>
                </h1>
                <p className="welcome-copy">
                  Sua convenção coletiva, traduzida para a rotina do RH.
                  <br />O que você gostaria de pesquisar hoje?
                </p>
                <div className="suggestion-grid">
                  {suggestions.map(({ icon: Icon, title, text: detail, question }) => (
                    <Button
                      key={title}
                      variant="outline"
                      className="suggestion"
                      onClick={() => send(question)}
                    >
                      <span className="suggestion-icon">
                        <Icon size={20} strokeWidth={1.6} />
                      </span>
                      <span className="suggestion-copy">
                        <strong>{title}</strong>
                        <span>{detail}</span>
                      </span>
                      <ArrowUpRight size={16} className="suggestion-arrow" />
                    </Button>
                  ))}
                </div>
                <div className="topics">
                  <span>Temas frequentes</span>
                  <div>
                    {topics.map((topic) => (
                      <Button
                        key={topic}
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setText(
                            `Quais regras de ${topic.toLowerCase()} devo verificar na minha CCT?`,
                          );
                          input.current?.focus();
                        }}
                      >
                        {topic}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <Conversation className="transcript">
                <ConversationContent className="transcript-content">
                  {messages.map((m) => (
                    <Message key={m.id} from={m.role} className="chat-message">
                      {m.role === "assistant" && (
                        <div className="message-author">
                          <img src={mark} alt="" width={24} height={24} /> Convecta{" "}
                          <span>ANALISTA CCT</span>
                        </div>
                      )}
                      <MessageContent>
                        {m.parts.map((part, i) => {
                          if (part.type === "file" && part.mediaType.startsWith("image/"))
                            return <img key={i} src={part.url} alt={part.filename || "Imagem anexada"} className="max-h-80 max-w-full rounded-md object-contain" />;
                          if (part.type === "text")
                            return (
                              <MessageResponse
                                key={i}
                                isAnimating={busy && m.id === messages.at(-1)?.id}
                              >
                                {m.role === "user" && part.text.includes("<documento>")
                                  ? part.text.split("\n\nDocumento:")[0] +
                                    "\n\n📎 " +
                                    (part.text.split("Documento: ")[1]?.split("\n")[0] ||
                                      "Documento anexado")
                                  : part.text}
                              </MessageResponse>
                            );
                          if (part.type === "reasoning")
                            return (
                              <Reasoning
                                key={i}
                                defaultOpen={false}
                                isStreaming={part.state === "streaming"}
                              >
                                <ReasoningTrigger
                                  getThinkingMessage={(streaming) =>
                                    streaming ? "Analisando informações…" : "Etapas da análise"
                                  }
                                />
                                <ReasoningContent>{part.text}</ReasoningContent>
                              </Reasoning>
                            );
                          return null;
                        })}
                      </MessageContent>
                      {m.role === "assistant" && !busy && (
                        <MessageActions>
                          <MessageAction
                            tooltip="Copiar resposta"
                            onClick={() =>
                              copy(
                                m.id,
                                m.parts
                                  .filter((p) => p.type === "text")
                                  .map((p) => (p.type === "text" ? p.text : ""))
                                  .join("\n"),
                              )
                            }
                          >
                            {copied === m.id ? <Check size={15} /> : <Copy size={15} />}
                          </MessageAction>
                          <MessageAction
                            tooltip="Salvar como resumo"
                            onClick={() => {
                              setSaveFor(messageText(m));
                              setSaveForm({ unit: "", convention: "", validity: "" });
                              setSaveFile(null);
                              setSaved("");
                            }}
                          >
                            <BookmarkPlus size={15} />
                          </MessageAction>
                        </MessageActions>
                      )}
                    </Message>
                  ))}
                  {status === "submitted" && (
                    <div className="waiting">
                      <img src={mark} width={24} height={24} alt="" />
                      <Shimmer>Consultando as informações…</Shimmer>
                    </div>
                  )}
                </ConversationContent>
                <ConversationScrollButton />
              </Conversation>
            )}
            <div className="composer-area">
              {saved && (
                <div className="success-notice">
                  <span>
                    {saved}{" "}
                    <Link to="/biblioteca" onClick={() => setSaved("")}>
                      Ver na biblioteca
                    </Link>
                  </span>
                  <IconControl label="Fechar aviso" onClick={() => setSaved("")}>
                    <X size={16} />
                  </IconControl>
                </div>
              )}
              {(notice || error) && (
                <div role="alert" className="error-notice">
                  <span>{notice || error?.message}</span>
                  <IconControl
                    label="Fechar aviso"
                    onClick={() => {
                      setNotice("");
                      clearError();
                    }}
                  >
                    <X size={16} />
                  </IconControl>
                </div>
              )}
              {document && (
                <div className="attached-document">
                  <FileText size={17} />
                  <span>{document.name}</span>
                  <span className="file-status">Pronto para análise</span>
                  <IconControl label="Remover documento" onClick={() => setDocument(null)}>
                    <X size={14} />
                  </IconControl>
                </div>
              )}
              {images.map((image, index) => (
                <div className="attached-document" key={`${index}-${image.filename}`}>
                  <img src={image.url} alt={image.filename || "Imagem anexada"} className="h-14 w-14 shrink-0 rounded object-contain" />
                  <span>{image.filename}</span>
                  <IconControl label={`Remover imagem ${index + 1}`} onClick={() => setImages((current) => current.filter((_, i) => i !== index))}>
                    <X size={14} />
                  </IconControl>
                </div>
              ))}
              <PromptInput
                onSubmit={(message: PromptInputMessage) => send(message.text)}
                className="research-composer"
              >
                <PromptInputTextarea
                  ref={input}
                  aria-label="Sua pergunta"
                  placeholder="Pergunte sobre a sua CCT ou anexe uma convenção…"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  disabled={busy || reading}
                />
                <PromptInputFooter>
                  <div className="composer-tools">
                    <Button
                      variant="ghost"
                      size="sm"
                      type="button"
                      onClick={() => upload.current?.click()}
                      disabled={busy || reading}
                    >
                      <Paperclip size={17} />
                      {reading ? "Preparando arquivo…" : "Anexar arquivo"}
                    </Button>
                    <span className="composer-formats">Documentos ou imagens</span>
                  </div>
                  <PromptInputSubmit
                    aria-label={busy ? "Interromper resposta" : "Enviar pergunta"}
                    status={status}
                    onStop={stop}
                    disabled={!busy && (reading || (!text.trim() && !document && !images.length))}
                  >
                    {busy ? <Square size={16} /> : <ArrowUp size={19} />}
                  </PromptInputSubmit>
                </PromptInputFooter>
              </PromptInput>
              <input
                ref={upload}
                type="file"
                aria-label="Anexar convenção"
                className="hidden"
                accept=".pdf,.docx,.txt,.md,.jpg,.jpeg,.png,.webp"
                onChange={(e) => void attach(e.target.files?.[0])}
              />
              <div className="composer-disclaimer">
                <ShieldCheck size={12} />
                <span>
                  Apoio técnico ao RH/DP. Valide interpretações com sua assessoria jurídica.
                </span>
              </div>
            </div>
          </section>
          <footer className="workspace-footer">
            <span>
              CONVECTA <span className="footer-separator">/</span> INTELIGÊNCIA APLICADA AO TRABALHO
            </span>
            <span>
              Conversas apenas nesta sessão <span className="footer-dot">•</span> Sem histórico
              salvo
            </span>
          </footer>
        </main>
        {help && (
          <div className="help-backdrop" onClick={() => setHelp(false)}>
            <div
              className="help-dialog"
              role="dialog"
              aria-modal="true"
              aria-labelledby="help-title"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="help-header">
                <img src={mark} alt="" width={42} height={42} />
                <IconControl label="Fechar" onClick={() => setHelp(false)}>
                  <X />
                </IconControl>
              </div>
              <h2 id="help-title">Sobre o Convecta</h2>
              <p>
                Assistente de pesquisa e análise de convenções e acordos coletivos para RH e
                Departamento Pessoal.
              </p>
              <p>
                As conversas ficam somente nesta sessão e desaparecem ao atualizar ou fechar a
                página. Documentos são enviados como texto e fotos e prints como imagens para análise.
              </p>
              <p>
                Não há consulta à internet em tempo real. Envie a CCT aplicável para verificar
                cláusulas, datas e valores. PDF digitalizado sem texto precisa ser convertido antes.
              </p>
              <p>
                A IA pode cometer erros. Confirme obrigações com sua assessoria jurídica. O uso da
                IA consome créditos do Lovable.
              </p>
              <Button onClick={() => setHelp(false)}>Entendido</Button>
            </div>
          </div>
        )}
        <Dialog open={!!saveFor} onOpenChange={(open) => !open && setSaveFor("")}>
          <DialogContent className="save-dialog">
            <DialogHeader>
              <DialogTitle>Salvar como resumo</DialogTitle>
              <DialogDescription>
                Identifique a unidade e a convenção para organizar sua biblioteca de resumos.
              </DialogDescription>
            </DialogHeader>
            <div className="save-fields">
              <Label htmlFor="save-unit">Unidade</Label>
              <Input
                id="save-unit"
                value={saveForm.unit}
                onChange={(e) => setSaveForm({ ...saveForm, unit: e.target.value })}
                placeholder="Ex.: Matriz São Paulo"
              />
              <Label htmlFor="save-convention">Convenção</Label>
              <Input
                id="save-convention"
                value={saveForm.convention}
                onChange={(e) => setSaveForm({ ...saveForm, convention: e.target.value })}
                placeholder="Ex.: CCT Sindilojas 2025/2026"
              />
              <Label htmlFor="save-validity">Vigência (opcional)</Label>
              <Input
                id="save-validity"
                value={saveForm.validity}
                onChange={(e) => setSaveForm({ ...saveForm, validity: e.target.value })}
                placeholder="Ex.: 01/05/2025 a 30/04/2026"
              />
              <Label htmlFor="save-document">Documento original (opcional)</Label>
              <Input
                id="save-document"
                type="file"
                accept=".pdf,.docx,.txt,.md"
                onChange={(e) => setSaveFile(e.target.files?.[0] ?? null)}
              />
              {saveFile && <span className="file-status">Anexando: {saveFile.name}</span>}
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setSaveFor("")} disabled={saving}>
                Cancelar
              </Button>
              <Button onClick={() => void submitSave()} disabled={saving}>
                {saving ? "Salvando…" : "Salvar na biblioteca"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  );
}
