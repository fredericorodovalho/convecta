import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import type { UIMessage } from "ai";
export type SessionThread = { id: string; title: string; messages: UIMessage[] };
type Workspace = {
  threads: SessionThread[];
  add: () => string;
  save: (id: string, messages: UIMessage[]) => void;
  remove: (id: string) => void;
};
const WorkspaceContext = createContext<Workspace | null>(null);
export function ChatWorkspaceProvider({ children }: { children: ReactNode }) {
  const [threads, setThreads] = useState<SessionThread[]>([]);
  const add = useCallback(() => {
    const id = crypto.randomUUID();
    setThreads((all) => [...all, { id, title: "Nova pesquisa", messages: [] }]);
    return id;
  }, []);
  const save = useCallback((id: string, messages: UIMessage[]) => {
    const first = messages.find((m) => m.role === "user")?.parts.find((p) => p.type === "text");
    const title =
      first?.type === "text"
        ? (first.text.split("\n")[0] || "Nova pesquisa").slice(0, 48)
        : "Nova pesquisa";
    setThreads((all) => {
      const thread = { id, title, messages };
      return all.some((t) => t.id === id)
        ? all.map((t) => (t.id === id ? thread : t))
        : [...all, thread];
    });
  }, []);
  const remove = useCallback(
    (id: string) => setThreads((all) => all.filter((t) => t.id !== id)),
    [],
  );
  return (
    <WorkspaceContext.Provider value={{ threads, add, save, remove }}>
      {children}
    </WorkspaceContext.Provider>
  );
}
export function useChatWorkspace() {
  const context = useContext(WorkspaceContext);
  if (!context) throw new Error("Workspace unavailable");
  return context;
}
