import { createFileRoute } from "@tanstack/react-router";
import { CctChat } from "@/components/cct-chat";

// No head() here: the home route inherits title/description/og/twitter from
// __root.tsx, and ships no og:image so serve-time hosting can inject the
// project's social preview (explicit og:image or latest screenshot).
export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Convecta — Assistente de convenções coletivas" },
    { name: "description", content: "Pesquise e analise CCT e ACT com um assistente especializado em RH e Departamento Pessoal." },
    { property: "og:title", content: "Convecta — Assistente de convenções coletivas" },
    { property: "og:description", content: "Clareza para cada decisão trabalhista: cláusulas, benefícios, jornada e obrigações do RH." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

// IMPORTANT: Replace this placeholder. See ./README.md for routing conventions.
function Index() {
  return <CctChat />;
}
