import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { useChatWorkspace } from "@/components/chat-workspace";
import { CctChat } from "@/components/cct-chat";
export const Route = createFileRoute("/chat/$threadId")({
  validateSearch: (search: Record<string, unknown>) => ({
    pending: search["pending"] === true || search["pending"] === "true",
  }),
  head: () => ({
    meta: [
      { title: "Pesquisa CCT — Convecta" },
      {
        name: "description",
        content:
          "Conversa temporária para analisar convenções coletivas e esclarecer obrigações do RH/DP.",
      },
      { property: "og:title", content: "Pesquisa CCT — Convecta" },
      { property: "og:description", content: "Análise prática de convenções e acordos coletivos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ThreadPage,
});
function ThreadPage() {
  const { threadId } = Route.useParams();
  const { threads } = useChatWorkspace();
  const thread = threads.find((t) => t.id === threadId);
  const { pending } = Route.useSearch();
  return (
    <CctChat
      key={threadId}
      threadId={threadId}
      initialMessages={thread?.messages || []}
      pending={pending}
    />
  );
}
