import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { lovable } from "@/integrations/lovable";
import { supabase } from "@/integrations/supabase/client";
import mark from "@/assets/convecta-mark.png";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — Convecta" },
      {
        name: "description",
        content:
          "Entre com sua conta Google para acessar sua biblioteca de resumos de convenções coletivas.",
      },
      { property: "og:title", content: "Entrar — Convecta" },
      {
        property: "og:description",
        content: "Sua biblioteca de resumos de convenções coletivas, protegida por conta Google.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function destinationAfterLogin(): string {
  try {
    const stored = sessionStorage.getItem("convecta-pos-login");
    if (stored) {
      const url = new URL(stored, window.location.origin);
      if (url.origin === window.location.origin) return url.pathname + url.search;
    }
  } catch {
    /* storage unavailable */
  }
  return "/biblioteca";
}

function AuthPage() {
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) void navigate({ to: destinationAfterLogin(), replace: true });
    });
  }, [navigate]);

  async function signInWithGoogle() {
    setBusy(true);
    setError("");
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setError("Não foi possível iniciar a entrada. Tente novamente.");
      setBusy(false);
      return;
    }
    if (result.redirected) return; // The browser continues the flow outside the app.
    const { data } = await supabase.auth.getUser();
    if (data.user) void navigate({ to: destinationAfterLogin(), replace: true });
    else {
      setError("A entrada não foi concluída. Tente novamente.");
      setBusy(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <img src={mark} alt="" width={52} height={52} />
        <h1>Entrar no Convecta</h1>
        <p>
          Sua biblioteca de resumos de convenções coletivas é privada. Use sua conta Google para
          guardar e consultar os resumos salvos.
        </p>
        <Button className="auth-button" onClick={() => void signInWithGoogle()} disabled={busy}>
          {busy ? "Abrindo conta Google…" : "Continuar com Google"}
        </Button>
        {error && (
          <div role="alert" className="auth-error">
            {error}
          </div>
        )}
        <a href="/" className="auth-back">
          Voltar para a pesquisa
        </a>
      </div>
    </div>
  );
}
