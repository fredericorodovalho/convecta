import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { BookOpen, Download, FileText, Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { MessageResponse } from "@/components/ai-elements/message";
import { summariesQuery } from "@/lib/summaries-query";
import { filterSummaries, matchingClauses } from "@/lib/summary-search";
import type { SummaryRow } from "@/lib/summaries.server";
import { summariesToBlob } from "@/lib/summary-word";
import { downloadBlob } from "@/lib/download";
import mark from "@/assets/convecta-mark.png";

export const Route = createFileRoute("/_authenticated/pesquisa")({
  head: () => ({ meta: [
    { title: "Pesquisar resumos salvos — Convecta" },
    { name: "description", content: "Consulta privada de resumos CCT por unidade, convenção, vigência e conteúdo." },
    { property: "og:title", content: "Pesquisar resumos salvos — Convecta" },
    { property: "og:description", content: "Encontre e consulte seus resumos de convenções coletivas." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
    { name: "robots", content: "noindex" },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(summariesQuery),
  component: SummarySearchPage,
});

function SummarySearchPage() {
  const { data: summaries } = useSuspenseQuery(summariesQuery);
  const [query, setQuery] = useState("");
  const [unit, setUnit] = useState("");
  const [validity, setValidity] = useState("");
  const [opened, setOpened] = useState<SummaryRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const results = filterSummaries(summaries, { query, unit, validity });
  const units = [...new Set(summaries.map((row) => row.unit))].sort((a, b) => a.localeCompare(b, "pt-BR"));
  const validities = [...new Set(summaries.map((row) => row.validity).filter((value): value is string => !!value))].sort();
  async function exportWord(rows: SummaryRow[]) {
    if (!rows.length) return;
    setBusy(true);
    setError("");
    try {
      downloadBlob(await summariesToBlob(rows), "pesquisa-resumos-convecta.docx");
    } catch {
      setError("Não foi possível gerar o arquivo Word.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="library-shell">
      <header className="library-top flex-wrap">
        <Link to="/" className="brand"><img src={mark} alt="" width={36} height={36} /><span>convecta<span className="brand-dot">.</span></span></Link>
        <nav className="flex flex-wrap gap-2" aria-label="Navegação de resumos">
          <Button variant="ghost" size="sm" asChild><Link to="/">Assistente CCT</Link></Button>
          <Button variant="outline" size="sm" asChild><Link to="/biblioteca"><BookOpen size={15} /> Biblioteca</Link></Button>
        </nav>
      </header>
      <main className="library-main">
        <div className="library-heading mb-6"><h1><Search size={24} /> Consulta de cláusulas</h1><p>Digite uma palavra-chave, o nome da convenção ou o ano. Aparecem as cláusulas encontradas nos seus resumos salvos.</p></div>
        <div className="relative mb-5">
          <Search className="absolute left-3 top-3 text-muted-foreground" size={18} />
          <Input aria-label="Pesquisar resumos salvos" placeholder="Ex.: hora extra, piso, comércio 2026…" value={query} onChange={(e) => setQuery(e.target.value)} className="h-12 pl-10 pr-10" />
          {query && <Button variant="ghost" size="icon-sm" className="absolute right-2 top-2" aria-label="Limpar pesquisa" onClick={() => setQuery("")}><X size={16} /></Button>}
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="grid gap-2"><Label htmlFor="search-unit">Unidade</Label><Select value={unit || "all"} onValueChange={(v) => setUnit(v === "all" ? "" : v)}><SelectTrigger id="search-unit" className="w-full"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todas as unidades</SelectItem>{units.map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent></Select></div>
          <div className="grid gap-2"><Label htmlFor="search-validity">Vigência</Label><Select value={validity || "all"} onValueChange={(v) => setValidity(v === "all" ? "" : v)}><SelectTrigger id="search-validity" className="w-full"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todas as vigências</SelectItem>{validities.map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent></Select></div>
        </div>
        <div className="my-6 flex flex-wrap items-center justify-between gap-3 border-b border-border pb-4">
          <span role="status" className="text-sm text-muted-foreground">{results.length} {results.length === 1 ? "resumo encontrado" : "resumos encontrados"}</span>
          <div className="flex flex-wrap gap-2">
            {(query || unit || validity) && <Button variant="ghost" size="sm" onClick={() => { setQuery(""); setUnit(""); setValidity(""); }}>Limpar filtros</Button>}
            <Button variant="outline" size="sm" disabled={busy || !results.length} onClick={() => void exportWord(results)}><Download size={15} /> {busy ? "Gerando…" : "Baixar resultados em Word"}</Button>
          </div>
        </div>
        {error && <p role="alert" className="mb-4 text-sm text-destructive">{error}</p>}
        {!results.length ? <div className="py-14 text-center text-muted-foreground"><FileText size={32} className="mx-auto mb-4" /><h2 className="text-lg font-semibold text-foreground">{summaries.length ? "Nenhum resumo encontrado" : "Nenhum resumo salvo ainda"}</h2></div> :
          <ul className="summary-list">{results.map((row) => { const clauses = matchingClauses(row.content, query); return <li key={row.id} className="summary-card"><div className="summary-body"><div className="summary-meta"><strong>{row.unit}</strong>{row.validity && <span className="summary-validity">{row.validity}</span>}<span className="summary-date">{new Date(row.updated_at).toLocaleDateString("pt-BR")}</span></div><h2>{row.convention}</h2>{clauses.length ? <div className="grid gap-2">{clauses.map((c, i) => <blockquote key={i} className="whitespace-pre-wrap border-l-2 border-primary bg-muted/50 px-3 py-2 text-sm text-foreground">{c}</blockquote>)}</div> : <p className="summary-text">{row.content}</p>}<div className="summary-tools"><Button variant="outline" size="sm" onClick={() => setOpened(row)}><FileText size={15} /> Ver convenção resumida</Button></div></div></li>; })}</ul>}
      </main>
      <Dialog open={!!opened} onOpenChange={(open) => !open && setOpened(null)}><DialogContent className="max-h-[85dvh] overflow-y-auto sm:max-w-3xl" aria-describedby={undefined}><DialogHeader><DialogTitle>{opened?.convention}</DialogTitle></DialogHeader>{opened && <><div className="flex flex-wrap gap-3 text-sm text-muted-foreground"><span>{opened.unit}</span><span>{opened.validity}</span></div><div className="min-w-0 break-words"><MessageResponse>{opened.content}</MessageResponse></div><Button variant="outline" disabled={busy} onClick={() => void exportWord([opened])}><Download size={15} /> Baixar resumo em Word</Button></>}</DialogContent></Dialog>
    </div>
  );
}