import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { Suspense, useEffect, useMemo, useState } from "react";
import {
  Download,
  FileText,
  Library,
  LogOut,
  Pencil,
  Search,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  deleteSummary,
  saveSummary,
  type SummaryRow,
} from "@/lib/summaries.server";
import { summariesToBlob } from "@/lib/summary-word";
import { downloadBlob } from "@/lib/download";
import { supabase } from "@/integrations/supabase/client";
import mark from "@/assets/convecta-mark.png";
import { summariesQuery } from "@/lib/summaries-query";

export const Route = createFileRoute("/_authenticated/biblioteca")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Biblioteca de resumos — Convecta" },
      {
        name: "description",
        content: "Resumos de convenções coletivas organizados por unidade e convenção.",
      },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Biblioteca de resumos — Convecta" },
      { property: "og:description", content: "Resumos de convenções coletivas organizados por unidade e convenção." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: async ({ context }) => {
    await context.queryClient.ensureQueryData(summariesQuery);
  },
  component: LibraryPage,
});

function LibraryPage() {
  return (
    <Suspense fallback={<div className="library-loading">Carregando sua biblioteca…</div>}>
      <LibraryContent />
    </Suspense>
  );
}

function LibraryContent() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { data: summaries } = useSuspenseQuery(summariesQuery);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [editing, setEditing] = useState<SummaryRow | null>(null);
  const [form, setForm] = useState({ unit: "", convention: "", validity: "", content: "" });
  const [confirming, setConfirming] = useState<SummaryRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [email, setEmail] = useState("");

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setEmail(data.session?.user.email ?? ""));
  }, []);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return summaries;
    return summaries.filter((summary) =>
      [summary.unit, summary.convention, summary.validity ?? "", summary.content]
        .join(" ")
        .toLowerCase()
        .includes(term),
    );
  }, [summaries, search]);

  function toggle(id: string) {
    setSelected((all) => (all.includes(id) ? all.filter((x) => x !== id) : [...all, id]));
  }

  async function exportWord() {
    const chosen = selected.length ? filtered.filter((s) => selected.includes(s.id)) : filtered;
    if (!chosen.length) {
      setError("Nenhum resumo disponível para exportar.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const blob = await summariesToBlob(
        chosen.map((s) => ({
          unit: s.unit,
          convention: s.convention,
          validity: s.validity,
          content: s.content,
        })),
      );
      downloadBlob(blob, "resumos-convecta.docx");
    } catch {
      setError("Não foi possível gerar o arquivo Word.");
    } finally {
      setBusy(false);
    }
  }

  async function downloadDocument(summary: SummaryRow) {
    if (!summary.document_path) return;
    setError("");
    // Open the tab synchronously so the browser keeps the click as user activation.
    const tab = window.open("", "_blank");
    const { data, error: urlError } = await supabase.storage
      .from("summary-documents")
      .createSignedUrl(summary.document_path, 60, {
        download: summary.document_name ?? "documento-original",
      });
    if (urlError || !data?.signedUrl) {
      tab?.close();
      setError("Não foi possível baixar o documento original.");
      return;
    }
    if (tab) tab.location.href = data.signedUrl;
    else window.location.href = data.signedUrl;
  }

  function openEdit(summary: SummaryRow) {
    setEditing(summary);
    setForm({
      unit: summary.unit,
      convention: summary.convention,
      validity: summary.validity ?? "",
      content: summary.content,
    });
    setError("");
  }

  async function saveEdit() {
    if (!editing) return;
    if (!form.unit.trim() || !form.convention.trim() || !form.content.trim()) {
      setError("Unidade, convenção e conteúdo são obrigatórios.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await saveSummary({
        data: {
          id: editing.id,
          unit: form.unit.trim(),
          convention: form.convention.trim(),
          validity: form.validity.trim(),
          content: form.content,
          documentPath: editing.document_path ?? "",
          documentName: editing.document_name ?? "",
        },
      });
      setEditing(null);
      await queryClient.invalidateQueries({ queryKey: ["cct-summaries"] });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não foi possível salvar o resumo.");
    } finally {
      setBusy(false);
    }
  }

  async function removeSummary(summary: SummaryRow) {
    setBusy(true);
    setError("");
    try {
      if (summary.document_path)
        await supabase.storage.from("summary-documents").remove([summary.document_path]);
      await deleteSummary({ data: summary.id });
      setSelected((all) => all.filter((id) => id !== summary.id));
      setConfirming(null);
      await queryClient.invalidateQueries({ queryKey: ["cct-summaries"] });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não foi possível excluir o resumo.");
    } finally {
      setBusy(false);
    }
  }

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    void navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="library-shell">
      <header className="library-top">
        <Link to="/" className="brand">
          <img src={mark} alt="" width={36} height={36} />
          <span>
            convecta<span className="brand-dot">.</span>
          </span>
        </Link>
        <div className="library-user">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/pesquisa"><Search size={15} /> Consulta de cláusulas</Link>
          </Button>
          {email && <span title={email}>{email}</span>}
          <Button variant="ghost" size="sm" onClick={() => void signOut()}>
            <LogOut size={15} /> Sair
          </Button>
        </div>
      </header>

      <main className="library-main">
        <div className="library-heading">
          <h1>
            <Library size={22} /> Biblioteca de resumos
          </h1>
          <p>
            As respostas que você salvou ficam guardadas por unidade e convenção. Exporte tudo ou
            apenas os resumos marcados em um arquivo Word.
          </p>
        </div>

        <div className="library-toolbar">
          <div className="library-search">
            <Search size={16} />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar por unidade, convenção ou conteúdo…"
              aria-label="Buscar resumos"
            />
          </div>
          <Button onClick={() => void exportWord()} disabled={busy}>
            <Download size={16} />
            {selected.length ? `Exportar Word (${selected.length})` : "Exportar tudo em Word"}
          </Button>
        </div>

        {error && (
          <div role="alert" className="error-notice">
            <span>{error}</span>
          </div>
        )}

        {!filtered.length ? (
          <div className="library-empty">
            <FileText size={28} strokeWidth={1.4} />
            <h2>{summaries.length ? "Nada encontrado" : "Nenhum resumo salvo ainda"}</h2>
            <p>
              {summaries.length
                ? "Ajuste a busca para encontrar o resumo."
                : "Abra uma pesquisa, faça a análise e use “Salvar como resumo” na resposta."}
            </p>
            <Link to="/" className="library-cta">
              Ir para a pesquisa
            </Link>
          </div>
        ) : (
          <ul className="summary-list">
            {filtered.map((summary) => (
              <li key={summary.id} className={`summary-card ${selected.includes(summary.id) ? "picked" : ""}`}>
                <label className="summary-check">
                  <input
                    type="checkbox"
                    checked={selected.includes(summary.id)}
                    onChange={() => toggle(summary.id)}
                    aria-label={`Selecionar ${summary.unit}`}
                  />
                </label>
                <div className="summary-body">
                  <div className="summary-meta">
                    <strong>{summary.unit}</strong>
                    {summary.validity && <span className="summary-validity">{summary.validity}</span>}
                    <span className="summary-date">
                      {new Date(summary.updated_at).toLocaleDateString("pt-BR")}
                    </span>
                  </div>
                  <h2>{summary.convention}</h2>
                  <p className="summary-text">{summary.content}</p>
                  <div className="summary-tools">
                    <Button variant="outline" size="sm" onClick={() => openEdit(summary)}>
                      <Pencil size={14} /> Editar
                    </Button>
                    {summary.document_path && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => void downloadDocument(summary)}
                      >
                        <FileText size={14} /> {summary.document_name ?? "Documento"}
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="summary-delete"
                      onClick={() => setConfirming(summary)}
                    >
                      <Trash2 size={14} /> Excluir
                    </Button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>

      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="save-dialog">
          <DialogHeader>
            <DialogTitle>Editar resumo</DialogTitle>
            <DialogDescription>Ajuste a identificação ou o conteúdo deste resumo.</DialogDescription>
          </DialogHeader>
          <div className="save-fields">
            <Label htmlFor="edit-unit">Unidade</Label>
            <Input
              id="edit-unit"
              value={form.unit}
              onChange={(e) => setForm({ ...form, unit: e.target.value })}
            />
            <Label htmlFor="edit-convention">Convenção</Label>
            <Input
              id="edit-convention"
              value={form.convention}
              onChange={(e) => setForm({ ...form, convention: e.target.value })}
            />
            <Label htmlFor="edit-validity">Vigência</Label>
            <Input
              id="edit-validity"
              value={form.validity}
              onChange={(e) => setForm({ ...form, validity: e.target.value })}
            />
            <Label htmlFor="edit-content">Conteúdo</Label>
            <Textarea
              id="edit-content"
              rows={12}
              value={form.content}
              onChange={(e) => setForm({ ...form, content: e.target.value })}
            />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditing(null)} disabled={busy}>
              Cancelar
            </Button>
            <Button onClick={() => void saveEdit()} disabled={busy}>
              {busy ? "Salvando…" : "Salvar alterações"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!confirming} onOpenChange={(open) => !open && setConfirming(null)}>
        <DialogContent className="save-dialog">
          <DialogHeader>
            <DialogTitle>Excluir resumo</DialogTitle>
            <DialogDescription>
              {confirming
                ? `Remover “${confirming.unit} — ${confirming.convention}” da sua biblioteca. O documento original anexado também será removido.`
                : ""}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirming(null)} disabled={busy}>
              Cancelar
            </Button>
            <Button
              onClick={() => confirming && void removeSummary(confirming)}
              disabled={busy || !confirming}
            >
              {busy ? "Excluindo…" : "Excluir definitivamente"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
