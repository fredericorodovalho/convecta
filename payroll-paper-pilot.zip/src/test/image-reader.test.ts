import { describe, expect, it } from "vitest";
import { convertToModelMessages } from "ai";
import { validateImage } from "@/lib/image-reader";

describe("Photo attachments", () => {
  it.each(["image/jpeg", "image/png", "image/webp"])("accepts %s photos", (type) => {
    expect(() => validateImage({ type, size: 1024 })).not.toThrow();
  });
  it("rejects unsupported images", () => {
    expect(() => validateImage({ type: "image/svg+xml", size: 1024 })).toThrow();
  });
  it("preserves image bytes and MIME in model input", async () => {
    const url = "data:image/png;base64,aGVsbG8=";
    const converted = await convertToModelMessages([{
      role: "user", parts: [
        { type: "text", text: "Analise esta foto" },
        { type: "file", mediaType: "image/png", filename: "clausula.png", url },
      ],
    }]);
    expect(converted[0]?.content).toEqual([
      { type: "text", text: "Analise esta foto" },
      { type: "file", mediaType: "image/png", filename: "clausula.png", data: { type: "url", url: new URL(url) } },
    ]);
  });
});