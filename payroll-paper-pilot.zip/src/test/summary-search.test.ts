import { describe, expect, it } from "vitest";
import { filterSummaries, matchingClauses } from "@/lib/summary-search";

const rows = [
  { unit: "Matriz São Paulo", convention: "CCT Comércio", validity: "2026/2027", content: "Reajuste salarial de 5%." },
  { unit: "Filial Recife", convention: "ACT Metalúrgicos", validity: "2025/2026", content: "Banco de horas." },
];
const base = { query: "", unit: "", validity: "" };
describe("pesquisa de resumos", () => {
  it("searches unit, convention, validity and content without accents", () => {
    for (const query of ["sao paulo", "comercio", "2026/2027", "reajuste salarial"]) {
      expect(filterSummaries(rows, { ...base, query })).toEqual([rows[0]]);
    }
  });
  it("combines unit and validity filters", () => {
    expect(filterSummaries(rows, { ...base, unit: "Filial Recife", validity: "2025/2026" })).toEqual([rows[1]]);
    expect(filterSummaries(rows, { ...base, unit: "Filial Recife", validity: "2026/2027" })).toEqual([]);
  });
  it("requires every search term and restores all rows when cleared", () => {
    expect(filterSummaries(rows, { ...base, query: "comercio horas" })).toEqual([]);
    expect(filterSummaries(rows, base)).toEqual(rows);
  });
  it("returns only the clauses that mention the keyword", () => {
    const content = "Cláusula 3 – Piso salarial de R$ 2.142,00.\n\nCláusula 4 – Hora extra com 60%.";
    expect(matchingClauses(content, "hora extra")).toEqual(["Cláusula 4 – Hora extra com 60%."]);
    expect(matchingClauses(content, "")).toEqual([]);
  });
});