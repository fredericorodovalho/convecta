import { describe, expect, it } from "vitest";
import { summaryRow } from "@/lib/summary-row";

const base = {
  unit: " Matriz São Paulo ",
  convention: " CCT Sindlojas 2025/2026 ",
  validity: " 01/05/2025 a 30/04/2026 ",
  content: "Piso salarial R$ 2.142,00.",
};

describe("summaryRow", () => {
  it("trims the identification fields and records the owner", () => {
    const row = summaryRow(base, "11111111-1111-1111-1111-111111111111");
    expect(row.unit).toBe("Matriz São Paulo");
    expect(row.convention).toBe("CCT Sindlojas 2025/2026");
    expect(row.validity).toBe("01/05/2025 a 30/04/2026");
    expect(row.user_id).toBe("11111111-1111-1111-1111-111111111111");
  });

  it("stores an absent document as NULL, never an empty string", () => {
    const row = summaryRow({ ...base, documentPath: "", documentName: "" }, "u");
    expect(row.document_path).toBeNull();
    expect(row.document_name).toBeNull();

    const missing = summaryRow(base, "u");
    expect(missing.document_path).toBeNull();
    expect(missing.document_name).toBeNull();
  });

  it("keeps the uploaded document inside the owner's folder", () => {
    const row = summaryRow(
      { ...base, documentPath: "u/1700000000-cct.pdf", documentName: "cct.pdf" },
      "u",
    );
    expect(row.document_path).toBe("u/1700000000-cct.pdf");
    expect(row.document_name).toBe("cct.pdf");
  });

  it("leaves the vigência empty when it is not informed", () => {
    expect(summaryRow({ ...base, validity: "   " }, "u").validity).toBe("");
  });
});
