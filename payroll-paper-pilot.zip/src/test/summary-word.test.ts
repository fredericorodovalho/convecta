import { describe, expect, it } from "vitest";
import { Packer } from "docx";
import {
  buildSummariesDoc,
  markdownToParagraphs,
  summariesToBlob,
} from "@/lib/summary-word";

const summaries = [
  {
    unit: "Matriz São Paulo",
    convention: "CCT Sindilojas 2025/2026",
    validity: "01/05/2025 a 30/04/2026",
    content:
      "## Identificação da convenção\n- Partes: **Sindilojas** e sindicato dos empregados\n1. Conferir piso salarial\n2. Conferir banco de horas",
  },
  {
    unit: "Filial Recife",
    convention: "ACT Metalúrgicos 2026",
    content: "Texto simples de síntese.",
  },
];

describe("summary-word", () => {
  it("preserves headings, bullets and numbered items", () => {
    const paragraphs = markdownToParagraphs(
      "# Título\n## Subtítulo\n- item **destaque**\n3. passo\n\nparágrafo",
    );
    expect(paragraphs).toHaveLength(5);
  });

  it("skips empty lines instead of dropping content", () => {
    const paragraphs = markdownToParagraphs("linha 1\n\n\nlinha 2");
    expect(paragraphs).toHaveLength(2);
  });

  it("builds a valid Word package with one table per summary", async () => {
    const buffer = await Packer.toBuffer(buildSummariesDoc(summaries));
    // OOXML files are ZIP packages: the first two bytes are always "PK".
    expect([...buffer.subarray(0, 2)]).toEqual([0x50, 0x4b]);
    const blob = await summariesToBlob(summaries);
    expect(blob.size).toBeGreaterThan(1000);
  });
});
