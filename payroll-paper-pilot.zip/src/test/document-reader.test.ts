import { describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({ destroy: vi.fn(), document: vi.fn(), extract: vi.fn() }));
vi.mock("pdfjs-dist", () => ({ GlobalWorkerOptions: {}, getDocument: mocks.document }));
vi.mock("pdfjs-dist/build/pdf.worker.min.mjs?url", () => ({ default: "worker.js" }));
vi.mock("mammoth/mammoth.browser", () => ({ extractRawText: mocks.extract }));
import { readDocument } from "@/lib/document-reader";
const file = (name: string) =>
  ({
    name,
    size: 10,
    arrayBuffer: async () => new ArrayBuffer(10),
    text: async () => "Texto da convenção",
  }) as File;
describe("Document reader", () => {
  it("reads text documents", async () => {
    expect(await readDocument(file("cct.txt"))).toContain("convenção");
  });
  it("reads DOCX documents", async () => {
    mocks.extract.mockResolvedValue({ value: "Cláusula primeira" });
    expect(await readDocument(file("cct.docx"))).toContain("Cláusula");
  });
  it("destroys the PDF loading task after extracting pages", async () => {
    mocks.document.mockReturnValue({
      promise: Promise.resolve({
        numPages: 1,
        getPage: async () => ({
          getTextContent: async () => ({ items: [{ str: "Piso salarial" }] }),
        }),
      }),
      destroy: mocks.destroy,
    });
    expect(await readDocument(file("cct.pdf"))).toContain("Piso salarial");
    expect(mocks.destroy).toHaveBeenCalled();
  });
  it("rejects empty files", async () => {
    await expect(
      readDocument({ ...file("empty.txt"), text: async () => "" } as File),
    ).rejects.toThrow("Não encontrei texto");
  });
  it("rejects scanned PDFs without treating page labels as extracted text", async () => {
    mocks.document.mockReturnValue({
      promise: Promise.resolve({
        numPages: 1,
        getPage: async () => ({ getTextContent: async () => ({ items: [] }) }),
      }),
      destroy: mocks.destroy,
    });
    await expect(readDocument(file("scan.pdf"))).rejects.toThrow("Não encontrei texto");
  });
});
