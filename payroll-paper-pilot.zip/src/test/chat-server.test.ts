import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  call: vi.fn(),
  convert: vi.fn(),
  validate: vi.fn(),
  forward: vi.fn(),
}));
vi.mock("ai", () => ({
  convertToModelMessages: mocks.convert,
  validateUIMessages: mocks.validate,
}));
vi.mock("@/lib/ai/responses.server", () => ({ createResponsesCall: mocks.call }));
vi.mock("@/lib/ai/run-id.ts", () => ({ withLovableAiGatewayRunIdHeader: mocks.forward }));
import { handleChat } from "@/lib/ai/chat.server";

function request() {
  return new Request("http://localhost/api/chat", {
    method: "POST",
    body: JSON.stringify({
      messages: [{ id: "one", role: "user", parts: [{ type: "text", text: "O que é CCT?" }] }],
    }),
  });
}
function result(events: unknown[]) {
  const response = new Response("stream");
  mocks.call.mockReturnValue({
    result: {
      fullStream: {
        async *[Symbol.asyncIterator]() {
          yield* events;
        },
      },
      toUIMessageStreamResponse: () => response,
    },
    gateway: {},
  });
  return response;
}
describe("Chat server", () => {
  beforeEach(() => {
    vi.resetAllMocks();
    vi.stubEnv("LOVABLE_API_KEY", "test-key");
    mocks.validate.mockImplementation(async ({ messages }) => messages);
    mocks.convert.mockResolvedValue([]);
    mocks.forward.mockImplementation((response) => response);
  });
  it("preserves an upstream denial after the SDK local start event", async () => {
    result([
      { type: "start" },
      {
        type: "error",
        error: {
          statusCode: 403,
          responseBody: JSON.stringify({ message: "Acesso indisponível." }),
        },
      },
    ]);
    const response = await handleChat(request());
    expect(response.status).toBe(403);
    expect(await response.text()).toBe("Acesso indisponível.");
    expect(mocks.call).toHaveBeenCalledTimes(1);
  });
  it("forwards an accepted stream with gateway correlation", async () => {
    const expected = result([{ type: "start" }, { type: "start-step" }]);
    expect(await handleChat(request())).toBe(expected);
    expect(mocks.forward).toHaveBeenCalledTimes(1);
  });
  it("handles cancellation without retrying", async () => {
    result([{ type: "start" }, { type: "abort" }]);
    expect((await handleChat(request())).status).toBe(499);
    expect(mocks.call).toHaveBeenCalledTimes(1);
  });
  it("rejects remote image URLs before any gateway call", async () => {
    const response = await handleChat(new Request("http://localhost/api/chat", {
      method: "POST", body: JSON.stringify({ messages: [{
        id: "image", role: "user", parts: [{
          type: "file", mediaType: "image/png", url: "https://example.com/private.png",
        }],
      }] }),
    }));
    expect(response.status).toBe(400);
    expect(mocks.call).not.toHaveBeenCalled();
  });
  it("forwards inline photo attachments for analysis", async () => {
    result([{ type: "start-step" }]);
    const photo = { type: "file", mediaType: "image/png", url: "data:image/png;base64,aGVsbG8=" };
    const response = await handleChat(new Request("http://localhost/api/chat", {
      method: "POST", body: JSON.stringify({ messages: [{ id: "image", role: "user", parts: [photo] }] }),
    }));
    expect(response.status).toBe(200);
    expect(mocks.convert).toHaveBeenCalledWith([{ id: "image", role: "user", parts: [photo] }]);
  });
});
