CREATE TABLE public.cct_summaries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL DEFAULT auth.uid(),
 unit text NOT NULL,
 convention text NOT NULL,
 validity text NOT NULL DEFAULT '',
 content text NOT NULL,
 document_path text,
 document_name text,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cct_summaries TO authenticated;
GRANT ALL ON public.cct_summaries TO service_role;
ALTER TABLE public.cct_summaries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners manage summaries" ON public.cct_summaries FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid() AND (document_path IS NULL OR split_part(document_path, '/', 1) = auth.uid()::text));
CREATE INDEX cct_summaries_owner_updated ON public.cct_summaries (user_id, updated_at DESC);
CREATE POLICY "Owners read summary documents" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'summary-documents' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Owners upload summary documents" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'summary-documents' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Owners delete summary documents" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'summary-documents' AND (storage.foldername(name))[1] = auth.uid()::text);