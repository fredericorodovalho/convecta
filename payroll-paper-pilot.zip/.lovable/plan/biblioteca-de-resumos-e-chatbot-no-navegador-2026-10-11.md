# Biblioteca de resumos e chatbot no navegador

## O que será entregue
- Manter o Convecta acessível pelo navegador, com o chatbot de pesquisa existente.
- Adicionar entrada com Google para proteger os documentos e resumos de cada pessoa.
- Criar uma biblioteca permanente de resumos, organizada por unidade, convenção e vigência, com busca, edição e exclusão.
- Permitir salvar uma resposta do chatbot como resumo, identificando a unidade e a convenção antes de confirmar.
- Guardar os documentos originais associados aos resumos para consulta e download.
- Exportar os resumos selecionados ou toda a biblioteca em um arquivo Word acumulado.

## Formato do Word
Seguir o modelo anexado: tabela com as colunas **UNIDADE** e **CONVENÇÃO**. Na segunda coluna, apresentar identificação da convenção, partes envolvidas, abrangência, principais disposições e síntese. Manter títulos, listas e destaques legíveis, sem copiar os cortes de texto existentes no arquivo de referência.

## Histórico e conteúdo existente
- Os resumos e documentos ficarão salvos após fechar ou atualizar o navegador.
- As conversas de pesquisa continuarão temporárias; apenas as respostas escolhidas serão incorporadas à biblioteca.
- O Word anexado será usado como referência de formato, não como fonte de obrigações atuais. A importação completa dos resumos antigos não está incluída nesta etapa: a leitura disponível do anexo cobriu somente as primeiras 50 páginas.
- A geração de novas análises depende de créditos de IA disponíveis; salvar, consultar e exportar resumos não dependerá da IA.

## Detalhes técnicos
- Lovable Cloud para registros e armazenamento privado de arquivos, com acesso restrito ao proprietário.
- Preservar AI Elements, protocolo de streaming existente e chamadas de IA exclusivamente no servidor.
- Biblioteca em páginas próprias autenticadas; pesquisa pública permanece acessível, com convite para entrar ao salvar.
- Geração de DOCX com tabela e estilos compatíveis com Word, sem enviar documentos privados a um endereço público.

## Verificação
- Salvar dois resumos de unidades diferentes, atualizar a página e confirmar que ambos reaparecem corretamente.
- Verificar consulta e download dos documentos e isolamento entre contas.
- Exportar o Word, conferir todas as páginas e testar que o chatbot continua funcionando dentro dos limites de créditos disponíveis.