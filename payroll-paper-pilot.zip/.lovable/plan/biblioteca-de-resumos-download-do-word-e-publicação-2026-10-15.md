# Biblioteca de resumos, download do Word e publicação

## O que será entregue
- Biblioteca de resumos em página própria, protegida por entrada com Google.
- Botão "Salvar como resumo" em cada resposta do chat: identifica unidade, convenção e vigência antes de confirmar; permite anexar o documento original (PDF, DOCX, TXT).
- Página da biblioteca com busca por unidade/convenção, visualização completa, edição, exclusão e download do documento original.
- Exportação em Word acumulado no formato do modelo enviado: tabela com as colunas UNIDADE e CONVENÇÃO; na segunda coluna, identificação da convenção, vigência e o conteúdo do resumo com títulos, listas e destaques legíveis. Exportar os resumos selecionados ou todos, direto do navegador.
- Publicar o aplicativo na internet e enviar o endereço para você testar: o chat fica acessível a quem receber o link; a biblioteca permanece privada por conta Google.

## Status
Já existem no backend: tabela de resumos privada por usuário, armazenamento privado de documentos e entrada com Google. Já criados nesta etapa: funções do servidor para listar/salvar/excluir resumos, gerador de Word e página de entrada.

## Falta implementar
- Página da biblioteca autenticada (busca, editar, excluir, baixar documento, exportar Word).
- Botão de salvar resumo e diálogo no chat, com convite para entrar quando o usuário não estiver logado.
- Link "Biblioteca de resumos" no menu lateral e estado de sessão na entrada.
- Atualização do estado de sessão na raiz do app (entrar/sair).
- Testes do gerador de Word e verificação no navegador: salvar dois resumos de unidades diferentes, atualizar a página, exportar o Word e conferir as páginas do arquivo.

## Detalhes técnicos
- Ler/escrever resumos somente por funções no servidor com sessão obrigatória; o banco restringe cada conta aos próprios registros.
- Documentos originais ficam em armazenamento privado, na pasta da conta; download por link assinado de curta duração.
- Word gerado no navegador com a biblioteca docx; download direto, sem enviar documentos privados a serviços externos.
- Publicação pelo botão de publicar; chat público, biblioteca só com entrada Google.
